"""
scheduler.py

WaterMe! Scheduler — computes watering durations and schedules with solar-based smart logic.

Author: Paidin Cash / th3count
Version: 0.7.4
Date: 2025-07-15
"""

from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Tuple, Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter, HTTPException
from astral import Observer
from astral.sun import sun
from configparser import ConfigParser

from core.logger import log_event

# ── Configuration & Paths ──────────────────────────────────────────────────────
router   = APIRouter()
HOME     = Path.home()
CONFIG   = ConfigParser()
CONFIG.read(HOME / "settings.cfg")

# Fallback for missing section header

def _cfg_str(key: str, default: str) -> str:
    if CONFIG.has_option("Time & Location", key):
        return CONFIG.get("Time & Location", key)
    return CONFIG.defaults().get(key, default)

def _cfg_float(key: str, default: float) -> float:
    if CONFIG.has_option("Time & Location", key):
        return CONFIG.getfloat("Time & Location", key)
    val = CONFIG.defaults().get(key)
    try:
        return float(val) if val is not None else default
    except (TypeError, ValueError):
        return default

TZ       = _cfg_str("timezone", "UTC")
LAT      = _cfg_float("gps_lat", 0.0)
LON      = _cfg_float("gps_lon", 0.0)
TZINFO   = ZoneInfo(TZ)
OBSERVER = Observer(latitude=LAT, longitude=LON, elevation=0)

if TZ == "UTC" or LAT == 0.0:
    log_event(
        "config_warning", "scheduler", "warning",
        {"msg": "Using fallback Time & Location parameters (check settings.cfg)",
         "timezone": TZ, "lat": LAT, "lon": LON}
    )

BASE_DIR      = Path(__file__).resolve().parent.parent
GARDEN_ZONES  = BASE_DIR / "garden_data" / "zones.json"
GARDEN_MAP    = BASE_DIR / "garden_data" / "map.json"
SCHEDULE_FILE = Path("data/schedule.json")
LIBRARY_DIR   = BASE_DIR / "library"
